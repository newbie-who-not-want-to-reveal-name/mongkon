function toggleForm() {
    document.getElementById("login-form").classList.toggle("hidden");
    document.getElementById("register-form").classList.toggle("hidden");
}
// Handle Login & Register
document.addEventListener("DOMContentLoaded", function () {
    const forms = document.querySelectorAll("form");
    
    forms.forEach(form => {
        form.addEventListener("submit", function (event) {
            event.preventDefault();
            const formData = new FormData(this);

            fetch("auth.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        alert("Registration successful! You can now log in.");
                        window.location.reload();
                    }
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error("Error:", error));
        });
    });

    // Dashboard Session Check
    if (window.location.pathname.includes("dashboard.html")) {
        fetch("session.php")
        .then(response => response.json())
        .then(data => {
            if (data.status === "logged_in") {
                document.getElementById("username").textContent = data.username;
            } else {
                window.location.href = "index.html";
            }
        })
        .catch(error => console.error("Session Check Error:", error));
    }
});
